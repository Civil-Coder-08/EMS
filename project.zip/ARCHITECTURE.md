# Architecture

## Layering

```
┌──────────────────────────────────────────────────────────────┐
│ Routes (src/routes/**)                                       │
│   - File-based routing via TanStack Router                   │
│   - _authenticated/ subtree is gated; loaders may call       │
│     protected server functions                               │
└─────────────────────────────┬────────────────────────────────┘
                              │
┌─────────────────────────────▼────────────────────────────────┐
│ Components (src/components/**)                               │
│   - Presentational + shadcn primitives                       │
│   - No direct DB access                                      │
└─────────────────────────────┬────────────────────────────────┘
                              │
┌─────────────────────────────▼────────────────────────────────┐
│ Server functions (src/lib/*.functions.ts)                    │
│   - createServerFn().inputValidator(zod).handler(...)        │
│   - requireSupabaseAuth middleware on every protected fn     │
│   - All business logic + authorization checks                │
└─────────────────────────────┬────────────────────────────────┘
                              │
┌─────────────────────────────▼────────────────────────────────┐
│ Database (Postgres via Lovable Cloud)                        │
│   - RLS on every public table                                │
│   - user_roles dedicated table + has_role() SECURITY DEFINER │
│   - Bootstrap trigger promotes first signup to admin         │
└──────────────────────────────────────────────────────────────┘
```

## Request Flow (authenticated read)

1. Browser navigates to `/employees`.
2. Route is under `_authenticated/`; the gate confirms there is a Supabase session, otherwise redirects to `/auth`.
3. The loader (or component) calls a server function via `useServerFn`.
4. The client middleware in `src/start.ts` attaches the Supabase bearer token.
5. The server fn middleware `requireSupabaseAuth` verifies the JWT and exposes a per-request Supabase client bound to the user.
6. The handler validates the input with Zod, then queries Postgres. RLS evaluates as the authenticated user.
7. JSON result returns to the client; TanStack Query caches it.

## Why RLS over service-role checks

The service-role key bypasses RLS and would force every server function to re-implement authorization. Instead, the per-user Supabase client + RLS guarantees that even a buggy server function cannot leak data the user shouldn't see.

## Why a separate `user_roles` table

Storing a `role` column on `profiles` allows any user with `UPDATE` on their own profile to escalate to admin. Roles live in `user_roles`, which only admins can modify — enforced by RLS policies that check membership inline.

## Why inline role checks in RLS

The `has_role()` SECURITY DEFINER function is used internally but is **not** executable by the `authenticated` role. RLS policies inline the membership check via `EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role = '...')`. This:

- Keeps the SECURITY DEFINER surface area minimal.
- Lets the planner reuse the `user_roles_pkey` index.
- Avoids any chance of a user calling `has_role(other_user_id, 'admin')` directly via the Data API.

## Coding Conventions

- **Files**: `*.functions.ts` = server RPC modules (client-safe import path); `*.server.ts` = server-only helpers.
- **Validation**: Zod schemas live next to the server fn that uses them.
- **Errors**: server fns throw `Response` with the right status code; UI uses `errorComponent` boundaries.
- **State**: TanStack Query for server state; React state for local UI.
- **Styling**: semantic tokens in `src/styles.css`; never hardcode `text-white`, `bg-black`, or hex values in components.
- **Routing**: every section is its own route file with a unique `head()` (title/description/og).
