# Contributing

## Development Setup

1. Clone the repository.
2. Run `bun install`.
3. Run `bun dev` to start the local dev server at `http://localhost:8080`.

## Tech Stack & Conventions

- **Framework**: TanStack Start v1 (React 19, Vite 7).
- **Styling**: Tailwind CSS v4 via `src/styles.css`. Use semantic theme tokens, never hardcode `text-white`, `bg-black`, or raw hex values in components.
- **Data**: TanStack Query for server state, React state for local UI.
- **Routing**: File-based in `src/routes/`. Every section gets its own route with a unique `head()` for title/description.
- **Server functions**: `createServerFn` from `@tanstack/react-start`, placed in `src/lib/*.functions.ts`.
- **Validation**: Zod schemas live next to the server function that uses them.
- **Database changes**: use the `supabase--migration` tool. Every `CREATE TABLE` must be followed by `GRANT` statements in the same migration.

## Code Style

- TypeScript `strict: true` — all imports must resolve.
- No `src/pages/` — file-based routing only.
- No SSR-unsafe imports (browser-only libraries) at module scope in files that run server-side.
- Prefer `search-replace` over full-file rewrites for small changes.

## Security

- All access control is enforced server-side via RLS and `requireSupabaseAuth` middleware.
- Never check roles with client-side storage or hardcoded credentials.
- If you add a new public table, enable RLS and write policies before granting `SELECT`/`INSERT`/`UPDATE`/`DELETE`.

## Testing

- Add unit tests for new Zod schemas and server-function validators.
- If you add UI behavior, verify it in the preview before claiming it works.

## Pull Request Process

1. Keep changes focused — one feature or fix per PR.
2. Ensure `bun run build` passes with no type errors.
3. Verify the route you changed renders correctly in the preview.
4. Update docs (`README.md`, `ARCHITECTURE.md`) if you changed data models or routing.
