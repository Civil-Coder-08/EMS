# Deployment Guide

This project is built on Lovable's managed stack. There is no Docker image, no Nginx config, and no certificate management to run yourself — the platform handles HTTPS, HSTS, and edge delivery.

## 1. Publish

1. Open the project in the Lovable editor.
2. Click **Publish** in the top-right.
3. The app is built and deployed to:
   - Stable preview: `https://project--<project-id>-dev.lovable.app`
   - Production:     `https://project--<project-id>.lovable.app`
   - Or your configured custom domain.

The build is immutable per publish; rolling back means publishing an earlier version.

## 2. Configure Auth Providers

Email/password is enabled by default. To enable Google sign-in:

1. Open **Backend → Authentication → Providers**.
2. Enable **Google** and paste your OAuth client ID + secret.
3. Add your published origin to **Authorized redirect URIs**.

## 3. Bootstrap the First Admin

The schema includes a trigger that promotes the **first** registered user to `admin`. Every subsequent signup defaults to `employee`.

1. After publishing, open the site and sign up with the email you want to use as the administrator.
2. That account is now `admin`. Verify by visiting **/employees** — the create/edit/delete actions should be visible.
3. To promote additional admins later, an existing admin can assign roles from the database (a UI for role management can be added on top of the existing `user_roles` policies).

## 4. Custom Domain (optional)

1. **Project Settings → Domains → Add domain**.
2. Add the CNAME record shown to your DNS provider.
3. The platform provisions a TLS certificate automatically. No mixed-content or "Not Secure" warnings will appear once DNS propagates.

## 5. Post-Deployment Checks

- [ ] First signup landed as `admin` (visible employee CRUD).
- [ ] Second signup landed as `employee` (read-only own record).
- [ ] `/auth` allows email + Google sign-in.
- [ ] `/reset-password` flow delivers the email.
- [ ] Dashboard charts render with seeded data.
- [ ] Browser shows a valid TLS lock — no warnings.

## 6. Updating

Push changes via the Lovable editor; every change is built and deployed to the preview URL automatically. Click **Publish** again to roll forward production.

## 7. Backups & Logs

- **Database backups**: managed by Lovable Cloud (daily, point-in-time).
- **Function logs**: **Backend → Functions → Logs**.
- **Analytics**: **Backend → Analytics**.

## 8. Rotating Secrets

If you ever need to rotate the backend API keys, use **Backend → Settings → API keys → Rotate**. The platform injects the new values into the build; you do not need to edit `.env`.
