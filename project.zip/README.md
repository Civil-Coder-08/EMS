# Secure Employee Management

Production-ready Employee Management System built on Lovable's stack (TanStack Start + React 19 + Vite + Lovable Cloud / Postgres). Follows OWASP Top 10 guidance, strict RBAC via a separate `user_roles` table, and Row-Level Security on every table.

## Features

- Email/password + Google sign-in (Lovable Cloud Auth)
- RBAC with `admin`, `hr`, `employee` roles enforced server-side via RLS
- First registered user is auto-promoted to `admin` (bootstrap trigger)
- Employee CRUD with Zod validation on every server function
- Dashboard with KPIs and charts (Recharts)
- Profile page + password reset flow
- Dark mode UI, semantic design tokens
- SSR-safe routes, type-safe routing via TanStack Router

## Tech Stack

| Layer       | Choice                                          |
| ----------- | ----------------------------------------------- |
| Framework   | TanStack Start v1 (React 19, Vite 7)            |
| Styling     | Tailwind CSS v4 (CSS-first config)              |
| Backend     | Lovable Cloud (managed Postgres + Auth)         |
| Server RPC  | `createServerFn` from `@tanstack/react-start`   |
| Validation  | Zod                                             |
| Data        | TanStack Query                                  |
| Charts      | Recharts                                        |

## Project Structure

```
src/
  components/
    app-shell.tsx           # Authenticated layout + nav
    ui/                     # shadcn primitives
  hooks/
    use-session.ts          # Client-side session tracker
  integrations/
    supabase/               # Auto-generated; do not edit
  lib/
    employees.functions.ts  # Zod-validated server functions
  routes/
    __root.tsx              # HTML shell + providers
    index.tsx               # Landing
    auth.tsx                # Sign in / sign up
    reset-password.tsx
    _authenticated/
      route.tsx             # Auth gate
      dashboard.tsx
      employees.tsx
      profile.tsx
  router.tsx
  start.ts                  # Middleware (Supabase auth attacher)
  styles.css                # Tailwind v4 theme tokens

supabase/
  migrations/               # Schema, RBAC, RLS policies
  config.toml
```

## Security Model

- **Roles in a dedicated table** (`public.user_roles`) — never on `profiles`. Prevents client-side privilege escalation.
- **RLS enabled on every public table** with explicit `GRANT`s.
- **Inline role checks** via `EXISTS` subqueries against `user_roles`; the `has_role` SECURITY DEFINER function is no longer executable by the `authenticated` role.
- **Server-side validation**: every mutation goes through `createServerFn().inputValidator(zodSchema).handler(...)`.
- **No service-role key in client code**. Admin operations live in `*.server.ts` modules.
- **Auth middleware**: `requireSupabaseAuth` attaches the user's JWT to protected server functions; loaders under `_authenticated/` only.
- **Bootstrap admin**: first signup is promoted to `admin` by a database trigger; subsequent signups default to `employee`.

## Data Model

| Table        | Purpose                                          |
| ------------ | ------------------------------------------------ |
| `profiles`   | One row per `auth.users.id`, holds display fields |
| `user_roles` | `(user_id, role)` with unique constraint          |
| `employees`  | Employee records (managed by admin/HR)            |

Roles enum: `admin | hr | employee`.

## Access Rules (plain English)

- **Admins and HR** can view all employees and all profiles.
- **Admins** can add, edit, and delete employees.
- **HR** can edit employees but not delete them.
- **Employees** can view only their own employee record and own profile.
- **Users** can view and update their own profile, and view their own role.
- **Admins** can view and manage all role assignments.

## Local Development

```bash
bun install
bun dev
```

The app runs at `http://localhost:8080`. Lovable Cloud env vars are injected automatically — see `.env.example` for the public-facing ones.

## Deployment

This project deploys via Lovable (Cloudflare Workers + managed Postgres). Click **Publish** in the Lovable editor.

- Preview URL: rebuilds on every change.
- Published URL: rebuilt on Publish.
- Custom domain: configure in Project Settings → Domains.

No Docker, Nginx, or VPS configuration is required. HTTPS, HSTS, and certificate management are handled by the platform — the deployed site will never produce a "Not Secure" warning when accessed via its `*.lovable.app` URL or a properly configured custom domain.

See [`DEPLOYMENT.md`](./DEPLOYMENT.md) for the full publish + first-admin bootstrap walkthrough.

## OWASP Top 10 Coverage

| Risk                                  | Mitigation                                                    |
| ------------------------------------- | ------------------------------------------------------------- |
| A01 Broken Access Control             | RLS + dedicated `user_roles` table + server-side role checks  |
| A02 Cryptographic Failures            | HTTPS enforced by platform; passwords hashed by Supabase Auth |
| A03 Injection                         | Parameterized queries (PostgREST / supabase-js), Zod input validation |
| A04 Insecure Design                   | Auth gate via `_authenticated/` layout; least-privilege grants |
| A05 Security Misconfiguration         | No service-role key client-side; secure cookies; CSP via platform |
| A06 Vulnerable Components             | Locked versions in `bun.lock`; `bun audit` in CI              |
| A07 Identification & Auth Failures    | Managed Auth (email + OAuth), password reset, no anon signups by default |
| A08 Software & Data Integrity         | Immutable build artifacts on deploy                           |
| A09 Logging & Monitoring              | Lovable Cloud function logs + analytics                       |
| A10 SSRF                              | No user-controlled outbound URLs in server functions          |

## Further Reading

- [`DEPLOYMENT.md`](./DEPLOYMENT.md) — publish + first-admin bootstrap
- [`ARCHITECTURE.md`](./ARCHITECTURE.md) — request flow, layering, conventions
- [`.env.example`](./.env.example) — required environment variables
