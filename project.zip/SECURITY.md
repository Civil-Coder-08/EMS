# Security Policy

## Supported Versions

This project is under active development. Only the latest published deployment receives security updates.

## Reporting a Vulnerability

If you discover a security issue in this project, please open a confidential issue via the project's issue tracker or contact the maintainer directly.

When reporting, include:
- A description of the vulnerability.
- Steps to reproduce.
- The affected route, component, or server function (if known).
- Your assessment of severity and impact.

Do not open a public pull request for undisclosed vulnerabilities.

## Security Model

- **RBAC**: roles live in a dedicated `user_roles` table, enforced by RLS.
- **No client-side privilege checks**: all authorization happens server-side.
- **Input validation**: Zod on every server function.
- **Auth**: managed by Lovable Cloud (email/password + Google OAuth).
- **No secrets in client bundles**: service-role key and database credentials are server-only.

## Accepted Risks

- Google OAuth email verification relies on the identity provider.
- First-user bootstrap admin promotion is a database trigger; physical database access can bypass this.
- RLS is the primary authorization layer; direct Supabase Admin API access (service role) bypasses it.
