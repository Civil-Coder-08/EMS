import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

export const EmployeeStatusEnum = z.enum(["active", "inactive", "on_leave", "terminated"]);
export const EmployeeGenderEnum = z.enum(["male", "female", "other", "prefer_not_to_say"]);

export const EmployeeInputSchema = z.object({
  employee_code: z.string().trim().min(2).max(32).regex(/^[A-Za-z0-9_-]+$/, "Letters, numbers, - or _ only"),
  full_name: z.string().trim().min(2).max(120),
  email: z.string().trim().toLowerCase().email().max(255),
  phone: z.string().trim().max(32).optional().or(z.literal("")),
  department: z.string().trim().min(1).max(80),
  designation: z.string().trim().min(1).max(120),
  salary: z.coerce.number().min(0).max(100_000_000),
  joining_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD"),
  gender: EmployeeGenderEnum.optional(),
  address: z.string().trim().max(500).optional().or(z.literal("")),
  status: EmployeeStatusEnum,
});

export type EmployeeInput = z.infer<typeof EmployeeInputSchema>;

const ListInputSchema = z.object({
  search: z.string().trim().max(120).optional(),
  department: z.string().trim().max(80).optional(),
  status: EmployeeStatusEnum.optional(),
  sortBy: z.enum(["created_at", "full_name", "joining_date", "salary"]).default("created_at"),
  sortDir: z.enum(["asc", "desc"]).default("desc"),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export const listEmployees = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ListInputSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const from = (data.page - 1) * data.pageSize;
    const to = from + data.pageSize - 1;

    let query = supabase
      .from("employees")
      .select("*", { count: "exact" })
      .order(data.sortBy, { ascending: data.sortDir === "asc" })
      .range(from, to);

    if (data.search) {
      const term = `%${data.search.replace(/[%_]/g, "")}%`;
      query = query.or(
        `full_name.ilike.${term},email.ilike.${term},employee_code.ilike.${term},designation.ilike.${term}`,
      );
    }
    if (data.department) query = query.eq("department", data.department);
    if (data.status) query = query.eq("status", data.status);

    const { data: rows, count, error } = await query;
    if (error) throw new Error(error.message);
    return { rows: rows ?? [], total: count ?? 0, page: data.page, pageSize: data.pageSize };
  });

export const getEmployee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("employees").select("*").eq("id", data.id).maybeSingle();
    if (error) throw new Error(error.message);
    return row;
  });

export const createEmployee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => EmployeeInputSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase
      .from("employees")
      .insert({
        employee_code: data.employee_code,
        full_name: data.full_name,
        email: data.email,
        phone: data.phone || null,
        department: data.department,
        designation: data.designation,
        salary: data.salary,
        joining_date: data.joining_date,
        gender: data.gender ?? null,
        address: data.address || null,
        status: data.status,
        created_by: userId,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateEmployee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), patch: EmployeeInputSchema.partial() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("employees")
      .update({
        ...data.patch,
        phone: data.patch.phone === "" ? null : data.patch.phone,
        address: data.patch.address === "" ? null : data.patch.address,
      })
      .eq("id", data.id)
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteEmployee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("employees").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getDashboardStats = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data: rows, error } = await supabase
      .from("employees")
      .select("id, department, status, joining_date, created_at, full_name, designation")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);

    const all = rows ?? [];
    const total = all.length;
    const active = all.filter((r) => r.status === "active").length;
    const inactive = all.filter((r) => r.status !== "active").length;
    const departments = new Set(all.map((r) => r.department)).size;

    const now = new Date();
    const monthly: { month: string; hires: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = d.toISOString().slice(0, 7);
      const label = d.toLocaleString("en-US", { month: "short" });
      const hires = all.filter((r) => (r.joining_date ?? "").startsWith(key)).length;
      monthly.push({ month: label, hires });
    }

    const byDepartment = Object.entries(
      all.reduce<Record<string, number>>((acc, r) => {
        acc[r.department] = (acc[r.department] ?? 0) + 1;
        return acc;
      }, {}),
    )
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);

    const recent = all.slice(0, 5).map((r) => ({
      id: r.id,
      full_name: r.full_name,
      designation: r.designation,
      department: r.department,
      created_at: r.created_at,
    }));

    return { total, active, inactive, departments, monthly, byDepartment, recent };
  });

export const getMyAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const [{ data: roles }, { data: profile }] = await Promise.all([
      supabase.from("user_roles").select("role").eq("user_id", userId),
      supabase.from("profiles").select("full_name, email").eq("id", userId).maybeSingle(),
    ]);
    return {
      userId,
      roles: (roles ?? []).map((r) => r.role) as ("admin" | "hr" | "employee")[],
      profile: profile ?? null,
    };
  });
