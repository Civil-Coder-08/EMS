import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getDashboardStats, getMyAccess } from "@/lib/employees.functions";
import { useHasSession } from "@/hooks/use-session";
import { Users, Building2, UserCheck, UserMinus, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, PieChart, Pie, Cell, CartesianGrid,
} from "recharts";

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: Dashboard,
});

const CHART_COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)", "var(--primary)"];

function Dashboard() {
  const fetchAccess = useServerFn(getMyAccess);
  const fetchStats = useServerFn(getDashboardStats);
  const hasSession = useHasSession();
  const { data: access } = useQuery({
    queryKey: ["my-access"], queryFn: () => fetchAccess(),
    staleTime: 60_000, enabled: hasSession === true, retry: false,
  });
  const isAdminOrHr = !!access?.roles.some((r) => r === "admin" || r === "hr");

  const { data, isLoading } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: () => fetchStats(),
    enabled: hasSession === true && isAdminOrHr,
    retry: false,
  });

  if (!isAdminOrHr) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-12">
        <h1 className="font-display text-2xl font-semibold">Welcome{access?.profile?.full_name ? `, ${access.profile.full_name.split(" ")[0]}` : ""}</h1>
        <p className="mt-2 text-muted-foreground">
          You're signed in as an <span className="font-medium text-foreground">employee</span>. Visit your profile to view your record.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl space-y-8 p-6 md:p-8">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight">Dashboard</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Live view of headcount, departments, and recent activity.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total employees" value={data?.total} icon={Users} tone="primary" loading={isLoading} />
        <StatCard label="Active" value={data?.active} icon={UserCheck} tone="success" loading={isLoading} />
        <StatCard label="Inactive" value={data?.inactive} icon={UserMinus} tone="warning" loading={isLoading} />
        <StatCard label="Departments" value={data?.departments} icon={Building2} tone="accent" loading={isLoading} />
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <div className="rounded-xl border border-border bg-card p-6 shadow-soft lg:col-span-3">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-semibold">Monthly hiring</h2>
              <p className="text-xs text-muted-foreground">Last 6 months</p>
            </div>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </div>
          <div className="h-64">
            {isLoading ? (
              <Skeleton className="h-full w-full" />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data?.monthly ?? []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }}
                    cursor={{ fill: "var(--accent)", opacity: 0.3 }}
                  />
                  <Bar dataKey="hires" fill="var(--primary)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-6 shadow-soft lg:col-span-2">
          <h2 className="font-display text-lg font-semibold">By department</h2>
          <p className="text-xs text-muted-foreground">Top {data?.byDepartment.length ?? 0}</p>
          <div className="mt-4 h-64">
            {isLoading ? (
              <Skeleton className="h-full w-full" />
            ) : (data?.byDepartment.length ?? 0) === 0 ? (
              <EmptyState label="No employees yet" />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={data?.byDepartment} dataKey="value" nameKey="name" innerRadius={50} outerRadius={85} paddingAngle={2}>
                    {data?.byDepartment.map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
          <ul className="mt-4 space-y-1.5 text-xs">
            {data?.byDepartment.map((d, i) => (
              <li key={d.name} className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full" style={{ background: CHART_COLORS[i % CHART_COLORS.length] }} />
                  <span className="text-muted-foreground">{d.name}</span>
                </span>
                <span className="font-medium tabular-nums">{d.value}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
        <h2 className="font-display text-lg font-semibold">Recent additions</h2>
        {isLoading ? (
          <Skeleton className="mt-4 h-24 w-full" />
        ) : (data?.recent.length ?? 0) === 0 ? (
          <EmptyState label="No recent activity" />
        ) : (
          <ul className="mt-4 divide-y divide-border">
            {data?.recent.map((r) => (
              <li key={r.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm font-medium">{r.full_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {r.designation} · {r.department}
                  </p>
                </div>
                <span className="text-xs text-muted-foreground">
                  {new Date(r.created_at).toLocaleDateString()}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function StatCard({
  label, value, icon: Icon, tone, loading,
}: {
  label: string;
  value: number | undefined;
  icon: React.ComponentType<{ className?: string }>;
  tone: "primary" | "success" | "warning" | "accent";
  loading: boolean;
}) {
  const toneClass = {
    primary: "bg-primary/10 text-primary",
    success: "bg-success/15 text-success",
    warning: "bg-warning/20 text-warning-foreground",
    accent: "bg-accent text-accent-foreground",
  }[tone];

  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-soft">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
          {loading ? (
            <Skeleton className="mt-2 h-8 w-16" />
          ) : (
            <p className="mt-2 font-display text-3xl font-semibold tabular-nums">{value ?? 0}</p>
          )}
        </div>
        <div className={"grid h-9 w-9 place-items-center rounded-lg " + toneClass}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
    </div>
  );
}

function EmptyState({ label }: { label: string }) {
  return <div className="grid h-full place-items-center text-sm text-muted-foreground">{label}</div>;
}
