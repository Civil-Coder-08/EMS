import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  listEmployees, createEmployee, updateEmployee, deleteEmployee, getMyAccess,
  EmployeeInputSchema, type EmployeeInput,
} from "@/lib/employees.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Pencil, Trash2, ChevronLeft, ChevronRight, ShieldAlert } from "lucide-react";
import { useHasSession } from "@/hooks/use-session";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/employees")({
  component: EmployeesPage,
});

type EmployeeRow = {
  id: string; employee_code: string; full_name: string; email: string; phone: string | null;
  department: string; designation: string; salary: number; joining_date: string;
  status: "active" | "inactive" | "on_leave" | "terminated"; created_at: string;
};

const STATUSES = ["active", "inactive", "on_leave", "terminated"] as const;
const GENDERS = ["male", "female", "other", "prefer_not_to_say"] as const;

function EmployeesPage() {
  const queryClient = useQueryClient();
  const fetchAccess = useServerFn(getMyAccess);
  const hasSession = useHasSession();
  const { data: access } = useQuery({
    queryKey: ["my-access"], queryFn: () => fetchAccess(),
    staleTime: 60_000, enabled: hasSession === true, retry: false,
  });
  const isAdmin = !!access?.roles.includes("admin");
  const isHr = !!access?.roles.includes("hr");
  const canRead = isAdmin || isHr;

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [page, setPage] = useState(1);
  const [sortBy, setSortBy] = useState<"created_at" | "full_name" | "joining_date" | "salary">("created_at");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [editing, setEditing] = useState<EmployeeRow | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState<EmployeeRow | null>(null);

  const fetchList = useServerFn(listEmployees);
  const createFn = useServerFn(createEmployee);
  const updateFn = useServerFn(updateEmployee);
  const deleteFn = useServerFn(deleteEmployee);

  const listInput = useMemo(
    () => ({
      search: search || undefined,
      status: statusFilter === "all" ? undefined : (statusFilter as EmployeeRow["status"]),
      sortBy, sortDir, page, pageSize: 10,
    }),
    [search, statusFilter, sortBy, sortDir, page],
  );

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ["employees", listInput],
    queryFn: () => fetchList({ data: listInput }),
    enabled: hasSession === true && canRead,
    retry: false,
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["employees"] });
    queryClient.invalidateQueries({ queryKey: ["dashboard-stats"] });
  };

  const createMut = useMutation({
    mutationFn: (input: EmployeeInput) => createFn({ data: input }),
    onSuccess: () => { toast.success("Employee created"); setCreating(false); invalidate(); },
    onError: (e: Error) => toast.error("Could not create", { description: humanError(e.message) }),
  });

  const updateMut = useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: EmployeeInput }) => updateFn({ data: { id, patch } }),
    onSuccess: () => { toast.success("Employee updated"); setEditing(null); invalidate(); },
    onError: (e: Error) => toast.error("Could not update", { description: humanError(e.message) }),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => { toast.success("Employee deleted"); setDeleting(null); invalidate(); },
    onError: (e: Error) => toast.error("Could not delete", { description: humanError(e.message) }),
  });

  if (!canRead) {
    return (
      <div className="mx-auto max-w-md px-6 py-20 text-center">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-destructive/10 text-destructive">
          <ShieldAlert className="h-6 w-6" />
        </div>
        <h1 className="mt-4 font-display text-xl font-semibold">Access denied</h1>
        <p className="mt-1 text-sm text-muted-foreground">Only Admin or HR roles can view employees.</p>
      </div>
    );
  }

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <div className="mx-auto max-w-7xl space-y-6 p-6 md:p-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold tracking-tight">Employees</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {data ? `${data.total} record${data.total === 1 ? "" : "s"}` : "Loading…"}
          </p>
        </div>
        {isAdmin && (
          <Button onClick={() => setCreating(true)}><Plus className="mr-2 h-4 w-4" /> Add employee</Button>
        )}
      </div>

      <div className="rounded-xl border border-border bg-card shadow-soft">
        <div className="flex flex-wrap items-center gap-3 border-b border-border p-4">
          <div className="relative flex-1 min-w-56">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Search name, email, code, designation…"
              value={search}
              onChange={(e) => { setPage(1); setSearch(e.target.value); }}
            />
          </div>
          <Select value={statusFilter} onValueChange={(v) => { setPage(1); setStatusFilter(v); }}>
            <SelectTrigger className="w-44"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {STATUSES.map((s) => <SelectItem key={s} value={s}>{labelOf(s)}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={`${sortBy}:${sortDir}`} onValueChange={(v) => {
            const [b, d] = v.split(":") as [typeof sortBy, typeof sortDir];
            setSortBy(b); setSortDir(d);
          }}>
            <SelectTrigger className="w-52"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="created_at:desc">Newest first</SelectItem>
              <SelectItem value="created_at:asc">Oldest first</SelectItem>
              <SelectItem value="full_name:asc">Name A→Z</SelectItem>
              <SelectItem value="full_name:desc">Name Z→A</SelectItem>
              <SelectItem value="salary:desc">Salary high→low</SelectItem>
              <SelectItem value="salary:asc">Salary low→high</SelectItem>
              <SelectItem value="joining_date:desc">Joined recent</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Employee</th>
                <th className="px-4 py-3 font-medium">Department</th>
                <th className="px-4 py-3 font-medium">Designation</th>
                <th className="px-4 py-3 font-medium">Joined</th>
                <th className="px-4 py-3 font-medium">Salary</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}><td colSpan={7} className="px-4 py-3"><Skeleton className="h-8 w-full" /></td></tr>
                ))
              ) : (data?.rows.length ?? 0) === 0 ? (
                <tr><td colSpan={7} className="px-4 py-16 text-center text-muted-foreground">
                  No employees match your filters.
                </td></tr>
              ) : (
                (data?.rows as EmployeeRow[]).map((row) => (
                  <tr key={row.id} className="hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <div className="font-medium">{row.full_name}</div>
                      <div className="text-xs text-muted-foreground">{row.email} · {row.employee_code}</div>
                    </td>
                    <td className="px-4 py-3">{row.department}</td>
                    <td className="px-4 py-3">{row.designation}</td>
                    <td className="px-4 py-3 tabular-nums">{new Date(row.joining_date).toLocaleDateString()}</td>
                    <td className="px-4 py-3 tabular-nums">${Number(row.salary).toLocaleString()}</td>
                    <td className="px-4 py-3"><StatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        {(isAdmin || isHr) && (
                          <Button size="icon" variant="ghost" onClick={() => setEditing(row)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                        )}
                        {isAdmin && (
                          <Button size="icon" variant="ghost" onClick={() => setDeleting(row)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between border-t border-border p-3 text-sm">
          <span className="text-muted-foreground">
            Page {data?.page ?? 1} of {totalPages} {isFetching && "· updating…"}
          </span>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}>
              <ChevronLeft className="h-4 w-4" /> Prev
            </Button>
            <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page >= totalPages}>
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <EmployeeFormDialog
        open={creating}
        onOpenChange={(o) => !o && setCreating(false)}
        title="Add employee"
        submitLabel="Create"
        submitting={createMut.isPending}
        onSubmit={(v) => createMut.mutate(v)}
      />
      <EmployeeFormDialog
        open={!!editing}
        onOpenChange={(o) => !o && setEditing(null)}
        title="Edit employee"
        submitLabel="Save changes"
        submitting={updateMut.isPending}
        initial={editing ? {
          employee_code: editing.employee_code,
          full_name: editing.full_name,
          email: editing.email,
          phone: editing.phone ?? "",
          department: editing.department,
          designation: editing.designation,
          salary: Number(editing.salary),
          joining_date: editing.joining_date,
          status: editing.status,
        } : undefined}
        onSubmit={(v) => editing && updateMut.mutate({ id: editing.id, patch: v })}
      />

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {deleting?.full_name}?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes the employee record. This action can't be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleting && deleteMut.mutate(deleting.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function StatusBadge({ status }: { status: EmployeeRow["status"] }) {
  const map: Record<EmployeeRow["status"], string> = {
    active: "bg-success/15 text-success border-success/30",
    inactive: "bg-muted text-muted-foreground border-border",
    on_leave: "bg-warning/25 text-warning-foreground border-warning/40",
    terminated: "bg-destructive/15 text-destructive border-destructive/30",
  };
  return <Badge variant="outline" className={map[status]}>{labelOf(status)}</Badge>;
}

function labelOf(s: string) {
  return s.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function humanError(msg: string) {
  if (/duplicate key/i.test(msg)) return "Employee code or email already exists.";
  if (/row-level security/i.test(msg)) return "You don't have permission for this action.";
  return msg;
}

function EmployeeFormDialog({
  open, onOpenChange, title, submitLabel, submitting, initial, onSubmit,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  title: string;
  submitLabel: string;
  submitting: boolean;
  initial?: Partial<EmployeeInput>;
  onSubmit: (v: EmployeeInput) => void;
}) {
  const form = useForm<EmployeeInput>({
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    resolver: zodResolver(EmployeeInputSchema) as any,
    values: {
      employee_code: initial?.employee_code ?? "",
      full_name: initial?.full_name ?? "",
      email: initial?.email ?? "",
      phone: initial?.phone ?? "",
      department: initial?.department ?? "",
      designation: initial?.designation ?? "",
      salary: initial?.salary ?? 0,
      joining_date: initial?.joining_date ?? new Date().toISOString().slice(0, 10),
      gender: initial?.gender,
      address: initial?.address ?? "",
      status: initial?.status ?? "active",
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>All fields are validated on the server before saving.</DialogDescription>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2" noValidate>
          <Field label="Employee code" error={form.formState.errors.employee_code?.message}>
            <Input {...form.register("employee_code")} placeholder="EMP-001" />
          </Field>
          <Field label="Status" error={form.formState.errors.status?.message}>
            <Select value={form.watch("status")} onValueChange={(v) => form.setValue("status", v as EmployeeInput["status"])}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{labelOf(s)}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Full name" error={form.formState.errors.full_name?.message} className="sm:col-span-2">
            <Input {...form.register("full_name")} />
          </Field>
          <Field label="Email" error={form.formState.errors.email?.message}>
            <Input type="email" {...form.register("email")} />
          </Field>
          <Field label="Phone" error={form.formState.errors.phone?.message}>
            <Input {...form.register("phone")} />
          </Field>
          <Field label="Department" error={form.formState.errors.department?.message}>
            <Input {...form.register("department")} placeholder="Engineering" />
          </Field>
          <Field label="Designation" error={form.formState.errors.designation?.message}>
            <Input {...form.register("designation")} placeholder="Senior Engineer" />
          </Field>
          <Field label="Salary" error={form.formState.errors.salary?.message}>
            <Input type="number" step="0.01" min="0" {...form.register("salary", { valueAsNumber: true })} />
          </Field>
          <Field label="Joining date" error={form.formState.errors.joining_date?.message}>
            <Input type="date" {...form.register("joining_date")} />
          </Field>
          <Field label="Gender" error={form.formState.errors.gender?.message}>
            <Select value={form.watch("gender") ?? ""} onValueChange={(v) => form.setValue("gender", v as EmployeeInput["gender"])}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>{GENDERS.map((g) => <SelectItem key={g} value={g}>{labelOf(g)}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Address" error={form.formState.errors.address?.message} className="sm:col-span-2">
            <Input {...form.register("address")} />
          </Field>
          <DialogFooter className="sm:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={submitting}>{submitLabel}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label, error, children, className,
}: { label: string; error?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={"space-y-2 " + (className ?? "")}>
      <Label>{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
