import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getMyAccess } from "@/lib/employees.functions";
import { useHasSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/profile")({
  component: ProfilePage,
});

type MyEmployee = {
  full_name: string;
  email: string;
  department: string;
  designation: string;
  joining_date: string;
  status: string;
  phone: string | null;
  address: string | null;
  employee_code: string;
} | null;

function ProfilePage() {
  const fetchAccess = useServerFn(getMyAccess);
  const hasSession = useHasSession();
  const { data: access, isLoading } = useQuery({
    queryKey: ["my-access"], queryFn: () => fetchAccess(),
    staleTime: 60_000, enabled: hasSession === true, retry: false,
  });
  const [employee, setEmployee] = useState<MyEmployee>(null);
  const [loadingEmp, setLoadingEmp] = useState(true);

  useEffect(() => {
    if (!access?.userId) return;
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("employees")
        .select("full_name, email, department, designation, joining_date, status, phone, address, employee_code")
        .eq("user_id", access.userId)
        .maybeSingle();
      if (!cancelled) {
        setEmployee(data as MyEmployee);
        setLoadingEmp(false);
      }
    })();
    return () => { cancelled = true; };
  }, [access?.userId]);

  return (
    <div className="mx-auto max-w-3xl space-y-6 p-6 md:p-8">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight">My profile</h1>
        <p className="mt-1 text-sm text-muted-foreground">Your account and employee record.</p>
      </div>

      <section className="rounded-xl border bg-card p-6 shadow-soft">
        <h2 className="font-display text-lg font-semibold">Account</h2>
        {isLoading ? (
          <Skeleton className="mt-4 h-20 w-full" />
        ) : (
          <dl className="mt-4 grid gap-4 sm:grid-cols-2">
            <Item label="Name" value={access?.profile?.full_name ?? "—"} />
            <Item label="Email" value={access?.profile?.email ?? "—"} />
            <Item label="Roles" value={
              <div className="flex flex-wrap gap-1">
                {access?.roles.map((r) => <Badge key={r} variant="secondary">{r}</Badge>)}
              </div>
            } />
          </dl>
        )}
      </section>

      <section className="rounded-xl border bg-card p-6 shadow-soft">
        <h2 className="font-display text-lg font-semibold">Employee record</h2>
        {loadingEmp ? (
          <Skeleton className="mt-4 h-24 w-full" />
        ) : !employee ? (
          <p className="mt-3 text-sm text-muted-foreground">
            No employee record is linked to your account yet. An administrator can link one to grant access to your details.
          </p>
        ) : (
          <dl className="mt-4 grid gap-4 sm:grid-cols-2">
            <Item label="Code" value={employee.employee_code} />
            <Item label="Department" value={employee.department} />
            <Item label="Designation" value={employee.designation} />
            <Item label="Status" value={employee.status} />
            <Item label="Joining date" value={new Date(employee.joining_date).toLocaleDateString()} />
            <Item label="Phone" value={employee.phone ?? "—"} />
            <Item label="Address" value={employee.address ?? "—"} className="sm:col-span-2" />
          </dl>
        )}
      </section>
    </div>
  );
}

function Item({ label, value, className }: { label: string; value: React.ReactNode; className?: string }) {
  return (
    <div className={className}>
      <dt className="text-xs uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="mt-1 text-sm font-medium">{value}</dd>
    </div>
  );
}
